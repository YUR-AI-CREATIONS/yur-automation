"""
Fleet integration tests — privacy, error handling, plugin loading.
"""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pytest

from src.superagents_fleet import FleetHub, AGENT_REGISTRY, list_agent_ids
from src.superagents_fleet.plugin.privacy import PrivacyFilter, PRIVATE_FIELD_PATTERNS
from src.superagents_fleet.plugin.registry import PluginRegistry, _validate_agent_id


def test_privacy_sanitize_recursive():
    """PrivacyFilter sanitize must recurse into nested dicts."""
    pf = PrivacyFilter()
    data = {"outer": {"inner": {"owner_ssn": "123-45-6789"}}}
    out = pf.sanitize(data)
    assert out["outer"]["inner"]["owner_ssn"] == "[REDACTED]"


def test_privacy_sanitize_for_learning_recursive():
    """sanitize_for_learning must recurse and redact high-sensitivity keys."""
    pf = PrivacyFilter()
    data = {"task": {"owner_ssn": "123", "parcel_id": "p001"}}
    out = pf.sanitize_for_learning(data)
    assert out["task"]["owner_ssn"] == "[REDACTED]"
    assert out["task"]["parcel_id"] == "p001"


def test_route_document_no_pii_leak():
    """route_document must not pass PII to tasks."""
    hub = FleetHub(audit=None, data_dir=Path(tempfile.mkdtemp()))
    tasks = hub.route_document({
        "type": "invoice",
        "id": "inv_1",
        "owner_ssn": "123-45-6789",
        "vendor_bank_account": "secret",
    })
    for agent_id, task in tasks:
        task_str = str(task)
        assert "owner_ssn" not in task_str
        assert "vendor_bank_account" not in task_str


def test_validate_agent_id():
    """agent_id must be alphanumeric + underscore."""
    assert _validate_agent_id("land_feasibility") is True
    assert _validate_agent_id("bid_scraping") is True
    assert _validate_agent_id("invalid-id") is False
    assert _validate_agent_id("123agent") is False
    assert _validate_agent_id("") is False


@pytest.mark.asyncio
async def test_dispatch_unknown_agent():
    """Dispatch to unknown agent returns structured error."""
    hub = FleetHub(audit=None, data_dir=Path(tempfile.mkdtemp()))
    r = await hub.dispatch("nonexistent_agent", {"task_id": "t1"})
    assert r["status"] == "failed"
    assert "Unknown agent" in r.get("error", "")


@pytest.mark.asyncio
async def test_dispatch_success():
    """Dispatch to land_feasibility succeeds."""
    hub = FleetHub(audit=None, data_dir=Path(tempfile.mkdtemp()))
    r = await hub.dispatch("land_feasibility", {"task_id": "t1", "type": "due_diligence", "parcel_id": "p001"})
    assert r["status"] == "success"
    assert r.get("result", {}).get("parcel_id") == "p001"


def test_list_agent_ids_phase_filter():
    """list_agent_ids filters by phase."""
    land = list_agent_ids("land")
    assert "land_feasibility" in land
    assert "bid_scraping" not in land
