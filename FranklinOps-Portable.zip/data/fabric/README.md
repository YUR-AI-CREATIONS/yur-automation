# Data Fabric

Minimum viable structure so the intelligence layer doesn't starve.

| Dir | Purpose |
|-----|---------|
| **raw/** | Original source, immutable |
| **clean/** | Normalized tables |
| **features/** | Model-ready |
| **runs/** | Every simulation run with trace_id |
| **evidence/** | PDFs, screenshots, hashes |

Every event points to: dataset version, evidence hash. That's how you prove your outputs.

## Ingestion (stub)

```python
# Future: wire Census, permits, parcel data
# from src.data_fabric.ingest import ingest_raw, normalize_to_clean, build_features
# ingest_raw(source="census", path="data/fabric/raw/census_2024.csv")
# normalize_to_clean(dataset="census")
# build_features(dataset="census")
```

Stub module: `src/data_fabric/ingest.py` (to be implemented).
