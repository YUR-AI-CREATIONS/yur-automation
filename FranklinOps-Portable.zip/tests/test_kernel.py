"""Unit tests for FranklinOps runtime kernel."""

import pytest

from src.core.kernel import create_kernel, KernelConfig, RuntimeKernel
from src.core.flow_interface import FlowSpec, FlowDirection, flow_handler


def test_kernel_config_from_create():
    kernel = create_kernel()
    assert kernel._config.db_path is not None
    assert "ops.db" in str(kernel._config.db_path)


def test_kernel_boot_shutdown():
    kernel = create_kernel()
    assert not kernel.booted
    kernel.boot()
    assert kernel.booted
    assert kernel.db is not None
    assert kernel.audit is not None
    kernel.shutdown()
    assert not kernel.booted


def test_kernel_invoke_echo():
    kernel = create_kernel()
    kernel.boot()
    try:
        kernel.plug(
            FlowSpec(flow_id="echo", name="Echo", direction=FlowDirection.INCOMING),
            flow_handler(lambda inp: {"out": inp, "flow_id": "echo"}),
        )
        result = kernel.invoke("echo", {"x": 1})
        assert result.ok is True
        assert result.out and result.out.get("out", {}).get("x") == 1
    finally:
        kernel.shutdown()
