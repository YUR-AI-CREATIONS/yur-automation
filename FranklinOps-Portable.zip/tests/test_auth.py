"""Unit tests for FranklinOps auth and RBAC."""

import pytest

from src.core.auth import (
    Role,
    ROUTE_ROLES,
    _path_prefix_match,
    resolve_user_from_request,
    validate_api_key,
)


def test_path_prefix_match():
    assert _path_prefix_match("/api/config") == {Role.ADMIN, Role.OPS, Role.VIEWER}
    assert _path_prefix_match("/api/admin") == {Role.ADMIN}
    assert _path_prefix_match("/api/development") == {Role.ADMIN, Role.OPS, Role.VIEWER}
    assert _path_prefix_match("/api/unknown") is None


def test_resolve_user_default():
    u = resolve_user_from_request()
    assert u["role"] == Role.OPS
    assert u["tenant_id"] == "default"


def test_resolve_user_x_role():
    u = resolve_user_from_request(x_role="admin")
    assert u["role"] == Role.ADMIN
    u = resolve_user_from_request(x_role="viewer")
    assert u["role"] == Role.VIEWER


def test_validate_api_key_empty_allowed():
    assert validate_api_key(None, []) is True
    assert validate_api_key("any", []) is True


def test_validate_api_key_required():
    assert validate_api_key(None, ["key1"]) is False
    assert validate_api_key("key1", ["key1"]) is True
    assert validate_api_key("key2", ["key1"]) is False
