# API Documentation

## Base URL
```
http://localhost:8000
```

## Endpoints

### Health Check

#### GET `/`
Root endpoint with API information.

#### GET `/health`
Health check for all system components.

### Cost Estimation

#### POST `/api/v1/estimate`
Generate a cost estimate for a construction project.

**Request Body:**
```json
{
    "name": "Office Building",
    "type": "commercial",
    "size": 5000,
    "complexity": "moderate"
}
```

### Project Management

#### POST `/api/v1/projects`
Create a new construction project.

#### GET `/api/v1/projects/{project_id}`
Get project details.

#### GET `/api/v1/projects/{project_id}/progress`
Get project progress status.

#### GET `/api/v1/projects`
List all projects.

### Bot Deployment

#### POST `/api/v1/bots/deploy`
Deploy autonomous bots.

**Bot Types:**
- `estimation_bot` - Cost estimation
- `construction_bot` - Construction management
- `software_builder_bot` - Software building
- `project_monitor_bot` - Monitoring
- `resource_allocator_bot` - Resource optimization
- `qa_bot` - Quality assurance

### Agents

#### POST `/api/v1/agents`
Create an autonomous task agent.

#### POST `/api/v1/agents/{agent_id}/execute`
Execute a task using a specific agent.

## Interactive Documentation

Visit when server is running:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`
