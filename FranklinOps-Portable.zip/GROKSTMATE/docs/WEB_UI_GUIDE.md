# Web UI Guide

## GROKSTMATE Interactive Web Interface

The web UI provides a visual, real-time view of autonomous agents and bots in action.

## Quick Start

```bash
# Start the web UI
grokstmate web

# Open your browser to:
http://localhost:8080
```

## Features

### 1. Visual Workflow Execution
- **5-Stage Pipeline**: Create Agent → Estimate Costs → Deploy Bots → Create Plan → Complete
- **Live Progress**: Stages light up in real-time as workflow progresses
- **Color Coding**: Active stages are highlighted with gradient effects

### 2. Live Agent Monitoring
- **Active Agents Panel**: Shows all running agents
- **Agent Cards**: Display name, domain, tasks completed, and status
- **Real-time Updates**: Agent status changes update instantly
- **Status Indicators**: 
  - 🟢 Ready (green)
  - 🟠 Working (orange)
  - ⚪ Idle (gray)

### 3. Bot Swarm Visualization
- **Deployed Bots Panel**: Shows all active bots
- **Bot Cards**: Display bot ID, type, tasks, and status
- **Swarm Tracking**: See all bots in the swarm
- **Types Supported**:
  - Estimation Bot
  - Construction Bot
  - Software Builder Bot
  - Project Monitor Bot
  - Resource Allocator Bot
  - QA Bot

### 4. Live Statistics Dashboard
- **Active Agents**: Real-time count
- **Deployed Bots**: Total bot count
- **Tasks Completed**: Running task counter
- **Auto-updating**: Updates every 5 seconds

### 5. Real-Time Event Log
- **Live Streaming**: Events appear as they happen
- **Color Coded**:
  - 🔵 Agent events (blue)
  - 🟠 Bot events (orange)
  - 🟢 Task events (green)
  - 🟣 Completion events (purple)
- **Timestamps**: Each event shows exact time
- **Auto-scroll**: New events appear at top
- **Event History**: Keeps last 50 events

### 6. WebSocket Connection
- **Real-time**: Bidirectional communication
- **Connection Status**: Shows "Connected" or "Disconnected"
- **Auto-reconnect**: Reconnects automatically if dropped
- **Keep-alive**: Pings every 30 seconds

## Using the Interface

### Starting a Workflow

1. Click the **"🚀 Start Autonomous Workflow"** button
2. Watch the workflow stages light up in sequence
3. See agents and bots spawn in real-time
4. Monitor the event log for detailed activity
5. View statistics update as tasks complete

### Workflow Stages

**Stage 1: Create Agent** (🤖)
- Spawns an Estimation Agent
- Agent initializes with capabilities
- Status changes from "initializing" to "ready"

**Stage 2: Estimate Costs** (📊)
- Agent executes estimation task
- Calculates project costs
- Returns detailed breakdown

**Stage 3: Deploy Bots** (🚀)
- Deploys swarm of 3 construction bots
- Each bot initializes independently
- Bots appear in "Deployed Bots" panel

**Stage 4: Create Plan** (📋)
- Spawns Project Manager Agent
- Creates comprehensive project plan
- Generates tasks and milestones

**Stage 5: Complete** (✅)
- Bots execute their tasks
- All tasks marked complete
- Workflow finishes successfully

### Understanding Agent Cards

```
┌─────────────────────────────┐
│ Estimation Agent            │ ← Agent Name
│ Domain: estimation          │ ← Specialization
│ Tasks: 1                    │ ← Completed Tasks
│ [idle]                      │ ← Current Status
└─────────────────────────────┘
```

### Understanding Bot Cards

```
┌─────────────────────────────┐
│ bot_construction_bot_0      │ ← Bot ID
│ Type: construction_bot      │ ← Bot Type
│ Tasks: 0                    │ ← Tasks Completed
│ [initializing]              │ ← Current Status
└─────────────────────────────┘
```

### Reading Event Log Entries

```
3:05:01 PM 🤖 Created agent: Estimation Agent
└──┬──┘    └┬┘ └──────────┬──────────────────┘
   │        │             └─ Event Description
   │        └─ Event Icon
   └─ Timestamp
```

## API Endpoints

The web UI runs on these endpoints:

- `GET /` - Main dashboard
- `GET /api/status` - System status JSON
- `POST /api/start-workflow` - Start demo workflow
- `GET /api/events` - Recent events JSON
- `WebSocket /ws` - Real-time updates

## Technical Details

### Architecture
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: FastAPI with WebSocket support
- **Real-time**: WebSocket for bidirectional communication
- **State Management**: Server-side with in-memory storage

### Performance
- **Lightweight**: No heavy frameworks
- **Fast**: Instant updates via WebSocket
- **Responsive**: Works on desktop, tablet, mobile
- **Efficient**: Minimal bandwidth usage

### Browser Requirements
- Modern browser with WebSocket support
- JavaScript enabled
- Recommended: Chrome, Firefox, Safari, Edge

## Troubleshooting

### Web UI won't start
```bash
# Make sure port 8080 is available
lsof -i :8080

# If busy, kill the process or use different port
uvicorn grokstmate.web_ui.app:app --port 8081
```

### Can't connect to WebSocket
- Check firewall settings
- Ensure browser allows WebSocket connections
- Try refreshing the page

### Events not appearing
- Check browser console for errors
- Verify WebSocket connection status (top-right)
- Click "Start Autonomous Workflow" button

### Agents/Bots not showing
- Wait for workflow to start
- Check that workflow is running (button disabled)
- Refresh page if needed

## Advanced Usage

### Running on Different Port

```bash
# In Python
import uvicorn
from grokstmate.web_ui.app import app
uvicorn.run(app, host="0.0.0.0", port=8081)
```

### Accessing from Network

```bash
# Start with host 0.0.0.0
grokstmate web

# Access from other devices
http://YOUR_IP:8080
```

### Programmatic Control

```python
from grokstmate.web_ui.app import workflow_manager

# Start workflow programmatically
import asyncio
asyncio.create_task(workflow_manager.run_demo_workflow())
```

## Tips

1. **Best Experience**: Use Chrome or Firefox for best WebSocket performance
2. **Multiple Windows**: Open multiple browser tabs to see sync
3. **Network Demo**: Run on local network to demo to team
4. **Screenshot Ready**: Interface is designed to look good in demos
5. **Auto-refresh**: Page automatically reconnects if connection drops

## What's Next?

Future enhancements could include:
- Custom workflow creation
- Manual agent/bot deployment controls
- Project import/export
- Historical workflow playback
- Multi-project dashboard
- Performance analytics
- Custom event filters
- Export reports

---

**Did somebody say lemonade?** 🍋

*Now you can see your construction empire running itself!*
