# GROKSTMATE Architecture

## Overview

GROKSTMATE is built on a modular, microservices-inspired architecture that enables autonomous operation of construction estimation and project management.

## System Components

### 1. Agent Framework (`agents/`)
The core autonomous agent system that powers decision-making and task execution.

**Components:**
- `BaseAgent`: Abstract base class for all agents
- `TaskAgent`: Specialized agents for specific domains

**Capabilities:**
- Autonomous task execution
- Decision-making based on context
- Inter-agent communication
- Learning from outcomes

### 2. Cost Estimation System (`estimating/`)
AI-powered construction cost estimation.

**Components:**
- `CostEstimator`: Main estimation engine

**Features:**
- Material cost calculation
- Labor rate estimation
- Equipment rental costs
- Timeline prediction
- Risk assessment

### 3. Project Management System (`project_management/`)
Autonomous project planning and tracking.

**Components:**
- `ProjectManager`: Core project management engine
- `ProjectStatus`: Project state management

**Features:**
- Automated project planning
- Resource allocation
- Progress monitoring
- Health assessment
- Risk management

### 4. Bot Deployment System (`bot_deployment/`)
Deploy and orchestrate specialized autonomous bots.

**Components:**
- `BotDeploymentManager`: Bot lifecycle management
- `Bot`: Individual bot implementation
- `BotType`: Bot type enumeration

**Features:**
- Swarm deployment
- Task orchestration
- Bot coordination
- Performance monitoring

### 5. API Layer (`api/`)
RESTful API for external integration.

**Components:**
- FastAPI application
- Pydantic models
- Endpoint handlers

**Features:**
- HTTP/REST interface
- Request validation
- Async operations
- Auto-generated documentation

### 6. CLI Interface (`cli.py`)
Command-line interface for local operations.

**Features:**
- Estimation commands
- Project management
- Bot deployment
- Agent creation
- Demo mode

## Data Flow

```
User Request
    ↓
CLI / API
    ↓
Business Logic Layer
    ├── CostEstimator
    ├── ProjectManager
    ├── BotDeploymentManager
    └── TaskAgent
    ↓
Autonomous Decision Engine
    ↓
Task Execution
    ↓
Results
```

## Autonomous Decision-Making

The system uses a multi-level autonomy model:

1. **Supervised**: Human approval required
2. **Semi-Autonomous**: Decisions with oversight
3. **Fully-Autonomous**: Complete autonomy

## Extensibility

The architecture is designed for easy extension:

- Add new agent types by extending `BaseAgent`
- Add new bot types by extending `Bot`
- Add new estimation methods to `CostEstimator`
- Add new API endpoints to `api/main.py`

## Scalability

- Async/await for concurrent operations
- Stateless API design
- Independent bot deployments
- Horizontal scaling ready
