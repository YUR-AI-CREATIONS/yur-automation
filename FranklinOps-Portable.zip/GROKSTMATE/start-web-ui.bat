@echo off
REM GROKSTMATE Easy Startup Script for Windows
REM This script will install dependencies and start the web UI

echo ==========================================
echo   GROKSTMATE Web UI - Easy Start
echo ==========================================
echo.

REM Check if setup.py exists
if not exist setup.py (
    echo Error: Please run this script from the GROKSTMATE root directory
    exit /b 1
)

echo Step 1: Installing dependencies...
pip install -q -e .
echo Dependencies installed
echo.

echo Step 2: Starting web UI server...
echo.
echo ==========================================
echo   Web UI will be available at:
echo   http://localhost:8080
echo ==========================================
echo.
echo INSTRUCTIONS:
echo   1. Open http://localhost:8080 in your browser
echo   2. Click the 'Start Autonomous Workflow' button
echo   3. Watch agents and bots work in real-time!
echo.
echo Press Ctrl+C to stop the server
echo.
echo Starting server now...
echo.

REM Start the web UI
python -m uvicorn grokstmate.web_ui.app:app --host 0.0.0.0 --port 8080
