# GROKSTMATE Quick Start Guide

## 🚀 How to See Agents in Action

### Option 1: One-Command Start (Easiest!)

**On Linux/Mac:**
```bash
./start-web-ui.sh
```

**On Windows:**
```bash
start-web-ui.bat
```

Then open your browser to: **http://localhost:8080**

---

### Option 2: Using the CLI

```bash
# Install first (if not already installed)
pip install -e .

# Start the web UI
grokstmate web
```

Then open your browser to: **http://localhost:8080**

---

### Option 3: Manual Start

```bash
# Install
pip install -e .

# Start server
python -m uvicorn grokstmate.web_ui.app:app --host 0.0.0.0 --port 8080
```

Then open your browser to: **http://localhost:8080**

---

## 📺 What You'll See

Once the browser opens at http://localhost:8080, you'll see:

1. **"Start Autonomous Workflow" button** - Click this!
2. **5 workflow stages** - These will light up as the workflow runs
3. **Live statistics** - Shows active agents, deployed bots, tasks completed
4. **Agent cards** - Shows each agent working with their status
5. **Bot cards** - Shows all deployed bots
6. **Event log** - Real-time stream of everything happening

## 🎬 Demo Workflow

When you click "Start Autonomous Workflow", here's what happens:

### Stage 1: Create Agent (🤖)
- An **Estimation Agent** spawns
- You'll see it in the "Active Agents" panel
- Status changes from "initializing" → "ready"

### Stage 2: Estimate Costs (📊)
- The agent executes a cost estimation task
- Event log shows: "Task started: Estimating commercial building costs"
- Then: "Task completed: estimate_project_001"

### Stage 3: Deploy Bots (🚀)
- **3 Construction Bots** deploy one by one
- Each appears in the "Deployed Bots" panel
- Event log shows: "Bot deployed: bot_construction_bot_0" (x3)

### Stage 4: Create Plan (📋)
- A **Project Manager Agent** spawns
- It creates a project plan with tasks and milestones
- Event log shows task creation and completion

### Stage 5: Complete (✅)
- All 3 bots execute their construction tasks
- Event log shows each bot completing work
- Final message: "🎉 Workflow complete! 5 tasks done."

## 📊 Live Statistics

Watch these numbers update in real-time:
- **Active Agents**: 0 → 2 (Estimation + Project Manager)
- **Deployed Bots**: 0 → 3 (Construction bots)
- **Tasks Completed**: 0 → 5 (All workflow tasks)

## 🔴 Troubleshooting

### "Command not found" or "Module not found"
```bash
# Make sure you're in the GROKSTMATE directory
cd GROKSTMATE-

# Install the package
pip install -e .

# Try again
grokstmate web
```

### Port 8080 already in use
```bash
# Use a different port
python -m uvicorn grokstmate.web_ui.app:app --port 8081

# Then open: http://localhost:8081
```

### Browser doesn't open automatically
Manually open your browser and go to:
```
http://localhost:8080
```

### Nothing happens when I click the button
1. Check the browser console (F12) for errors
2. Make sure the "Connected" indicator is green (top-right)
3. Refresh the page and try again

### I see "Disconnected" in the top-right
1. Make sure the server is running
2. Refresh the page
3. Check that no firewall is blocking port 8080

## 🎥 Video Demo

The workflow takes about 10 seconds to complete. Here's the sequence:

```
[0s]  Click button → Button disables, shows "Running workflow..."
[1s]  Estimation Agent appears
[2s]  Agent executes estimation task
[3s]  Bot #1 deploys
[4s]  Bot #2 deploys
[5s]  Bot #3 deploys
[6s]  Project Manager Agent appears
[7s]  PM Agent creates project plan
[8s]  Bot #1 executes task
[9s]  Bot #2 executes task
[10s] Bot #3 executes task → Workflow complete!
```

## 📱 Mobile/Tablet

The interface is responsive and works on:
- ✅ Desktop (best experience)
- ✅ Tablet (works well)
- ✅ Mobile (works but smaller)

## 🌐 Network Access

To access from other devices on your network:

1. Find your IP address:
   ```bash
   # Linux/Mac
   ip addr show | grep inet
   
   # Windows
   ipconfig
   ```

2. Start server with 0.0.0.0:
   ```bash
   python -m uvicorn grokstmate.web_ui.app:app --host 0.0.0.0 --port 8080
   ```

3. Access from other devices:
   ```
   http://YOUR_IP_ADDRESS:8080
   ```

## 💡 Tips

1. **Watch the event log** - It shows everything in real-time
2. **Colors matter** - Blue=agents, Orange=bots, Green=tasks, Purple=complete
3. **Run it multiple times** - Click the button again after it completes
4. **Open browser console (F12)** - See detailed WebSocket messages
5. **Multiple tabs** - Open multiple browser tabs to see sync

## ❓ Still Having Issues?

If nothing above works:

1. **Check Python version** (needs 3.9+):
   ```bash
   python --version
   ```

2. **Reinstall dependencies**:
   ```bash
   pip uninstall grokstmate
   pip install -e .
   ```

3. **Try the simple CLI demo** (no web UI):
   ```bash
   grokstmate demo
   ```

4. **Check for errors**:
   ```bash
   python -c "from grokstmate.web_ui.app import app; print('✓ Web UI loaded')"
   ```

## 🎯 Expected Result

After following these steps, you should see:
- ✅ Web UI loads in browser
- ✅ "Connected" indicator is green
- ✅ Click button starts workflow
- ✅ Agents and bots appear
- ✅ Events stream in log
- ✅ Statistics update
- ✅ Workflow completes in ~10 seconds

---

**Still stuck? The web UI requires:**
- Python 3.9+
- All dependencies from requirements.txt
- Port 8080 available (or use a different port)
- Modern browser with JavaScript enabled

**Did somebody say lemonade?** 🍋
