"""
Bot Swarm Deployment Example

Demonstrates deploying and coordinating multiple autonomous bots.
"""

import asyncio
from grokstmate.bot_deployment import BotDeploymentManager, BotType


async def main():
    print("=" * 70)
    print("GROKSTMATE - Bot Swarm Deployment")
    print("=" * 70)
    print()
    
    # Initialize bot manager
    manager = BotDeploymentManager()
    
    # Phase 1: Deploy Estimation Bots
    print("PHASE 1: Deploy Estimation Bot Swarm")
    print("-" * 70)
    
    estimation_bots = await manager.deploy_swarm(
        BotType.ESTIMATION_BOT,
        count=5,
        capabilities=["cost_estimation", "timeline_prediction"],
        config={"accuracy": "high"}
    )
    
    print(f"✓ Deployed {len(estimation_bots)} estimation bots")
    for bot_id in estimation_bots:
        print(f"  • {bot_id}")
    print()
    
    # Phase 2: Deploy Construction Bots
    print("PHASE 2: Deploy Construction Management Bots")
    print("-" * 70)
    
    construction_bots = await manager.deploy_swarm(
        BotType.CONSTRUCTION_BOT,
        count=3,
        capabilities=["site_management", "resource_tracking"],
        config={"supervision_level": "autonomous"}
    )
    
    print(f"✓ Deployed {len(construction_bots)} construction bots")
    for bot_id in construction_bots:
        print(f"  • {bot_id}")
    print()
    
    # Phase 3: Deploy Software Builder Bots
    print("PHASE 3: Deploy Software Builder Bots")
    print("-" * 70)
    
    software_bots = await manager.deploy_swarm(
        BotType.SOFTWARE_BUILDER_BOT,
        count=2,
        capabilities=["code_generation", "build_automation"],
        config={"language": "python"}
    )
    
    print(f"✓ Deployed {len(software_bots)} software builder bots")
    for bot_id in software_bots:
        print(f"  • {bot_id}")
    print()
    
    # Summary
    print("=" * 70)
    print("BOT SWARM DEPLOYMENT COMPLETED")
    print("=" * 70)
    print()
    
    stats = manager.get_bot_stats()
    print("Swarm Composition:")
    print(f"  • Estimation Bots:    {len(estimation_bots)}")
    print(f"  • Construction Bots:  {len(construction_bots)}")
    print(f"  • Software Bots:      {len(software_bots)}")
    print(f"  ─────────────────────────────")
    print(f"  • Total Active Bots:  {stats['total_bots_deployed']}")
    print()


if __name__ == "__main__":
    asyncio.run(main())
