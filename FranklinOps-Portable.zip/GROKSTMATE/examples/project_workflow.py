"""
Complete Project Workflow Example

Demonstrates a full project lifecycle from estimation to completion.
"""

import asyncio
from grokstmate.estimating import CostEstimator
from grokstmate.project_management import ProjectManager
from grokstmate.agents.task_agent import TaskAgent


async def main():
    print("=" * 70)
    print("GROKSTMATE - Complete Project Workflow")
    print("=" * 70)
    print()
    
    # Phase 1: Estimation
    print("PHASE 1: Project Estimation")
    print("-" * 70)
    
    estimator = CostEstimator()
    project_spec = {
        "name": "Modern Office Complex",
        "type": "commercial",
        "size": 15000,
        "complexity": "complex",
        "location": "San Francisco, CA"
    }
    
    estimate = estimator.estimate_project(project_spec)
    print(f"✓ Estimated Total Cost: ${estimate['total_estimate']:,.2f}")
    print(f"✓ Estimated Duration: {estimate['timeline_estimate']['duration_days']} days")
    print()
    
    # Phase 2: Project Planning
    print("PHASE 2: Project Planning")
    print("-" * 70)
    
    pm = ProjectManager("proj_workflow_001", project_spec["name"])
    plan = pm.create_project_plan(project_spec)
    
    print(f"✓ Created project plan with {len(plan['tasks'])} tasks")
    print(f"✓ Identified {len(plan['milestones'])} key milestones")
    print(f"✓ Assessed {len(plan['risks'])} potential risks")
    print()
    
    # Show milestones
    print("Key Milestones:")
    for milestone in plan['milestones']:
        print(f"  • {milestone['name']}")
    print()
    
    # Phase 3: Create Autonomous Agent
    print("PHASE 3: Deploy Autonomous Agent")
    print("-" * 70)
    
    agent = TaskAgent(
        agent_id="workflow_agent_001",
        name="Project Execution Agent",
        domain="construction",
        capabilities=[
            "estimation",
            "scheduling",
            "resource_allocation",
            "quality_control",
            "autonomous_decision_making"
        ],
        autonomy_level="fully-autonomous"
    )
    
    print(f"✓ Deployed agent: {agent.name}")
    print(f"✓ Autonomy level: {agent.autonomy_level}")
    print(f"✓ Capabilities: {len(agent.capabilities)} specialized skills")
    print()
    
    # Phase 4: Execute Tasks with Agent
    print("PHASE 4: Autonomous Task Execution")
    print("-" * 70)
    
    tasks = [
        {
            "task_id": "site_prep",
            "type": "project_management",
            "description": "Prepare construction site"
        },
        {
            "task_id": "foundation_estimate",
            "type": "estimation",
            "description": "Detailed foundation cost estimation"
        },
        {
            "task_id": "resource_plan",
            "type": "resource_allocation",
            "description": "Allocate resources for first phase"
        },
    ]
    
    for task in tasks:
        print(f"Executing: {task['description']}")
        result = await agent.execute_task(task)
        print(f"  Status: {result['status']}")
        print(f"  Agent: {result['agent_id']}")
        print()
    
    # Phase 5: Progress Tracking
    print("PHASE 5: Progress Tracking")
    print("-" * 70)
    
    # Simulate some task completion
    for task_id in list(pm.tasks.keys())[:3]:
        pm.update_task_status(task_id, "completed")
    
    progress = pm.track_progress()
    print(f"✓ Project Status: {progress['status']}")
    print(f"✓ Completion: {progress['completion_percentage']:.1f}%")
    print(f"✓ Tasks Completed: {progress['completed_tasks']}/{progress['total_tasks']}")
    print()
    
    # Phase 6: Health Assessment
    print("PHASE 6: Project Health Assessment")
    print("-" * 70)
    
    health = pm.assess_project_health()
    print(f"✓ Health Status: {health['health_status'].upper()}")
    print(f"✓ Health Score: {health['health_score']}/100")
    print(f"✓ On Schedule: {'Yes' if health['on_schedule'] else 'No'}")
    print(f"✓ Resource Utilization: {health['resource_utilization']:.1f}%")
    print()
    
    if health['recommendations']:
        print("Recommendations:")
        for rec in health['recommendations']:
            print(f"  • {rec}")
    print()
    
    # Summary
    print("=" * 70)
    print("PROJECT WORKFLOW COMPLETED SUCCESSFULLY")
    print("=" * 70)
    print()
    print("Summary:")
    print(f"  • Estimated Budget: ${estimate['total_estimate']:,.2f}")
    print(f"  • Total Tasks: {len(plan['tasks'])}")
    print(f"  • Agent Tasks Completed: {agent.tasks_completed}")
    print(f"  • Project Health: {health['health_status']}")
    print(f"  • Status: ACTIVE")
    print()


if __name__ == "__main__":
    asyncio.run(main())
