"""
Basic Cost Estimation Example

This example demonstrates how to use GROKSTMATE for simple cost estimation.
"""

from grokstmate.estimating import CostEstimator


def main():
    print("=" * 70)
    print("GROKSTMATE - Basic Cost Estimation Example")
    print("=" * 70)
    print()
    
    # Create estimator
    estimator = CostEstimator(region="US", currency="USD")
    
    # Define project specifications
    projects = [
        {
            "name": "Single Family Home",
            "type": "residential",
            "size": 2500,
            "complexity": "simple",
        },
        {
            "name": "Office Building",
            "type": "commercial",
            "size": 10000,
            "complexity": "moderate",
        },
        {
            "name": "Manufacturing Facility",
            "type": "industrial",
            "size": 50000,
            "complexity": "complex",
        },
    ]
    
    # Generate estimates for each project
    for project_spec in projects:
        print(f"\nProject: {project_spec['name']}")
        print("-" * 70)
        
        estimate = estimator.estimate_project(project_spec)
        
        print(f"Type: {estimate['project_type']}")
        print(f"Size: {project_spec['size']} sq ft")
        print(f"Complexity: {project_spec['complexity']}")
        print()
        
        # Show cost breakdown
        print("Cost Breakdown:")
        breakdown = estimate['breakdown']
        print(f"  Materials:  ${breakdown['materials']['total']:>12,.2f}")
        print(f"  Labor:      ${breakdown['labor']['total']:>12,.2f}")
        print(f"  Equipment:  ${breakdown['equipment']['total']:>12,.2f}")
        print(f"  Overhead:   ${breakdown['overhead']['total']:>12,.2f}")
        print(f"  {'─' * 30}")
        print(f"  Subtotal:   ${estimate['subtotal']:>12,.2f}")
        print(f"  Contingency:${estimate['contingency']:>12,.2f}")
        print(f"  {'═' * 30}")
        print(f"  TOTAL:      ${estimate['total_estimate']:>12,.2f}")
        print()
        
        # Show timeline
        timeline = estimate['timeline_estimate']
        print(f"Estimated Timeline: {timeline['duration_days']} days "
              f"({timeline['duration_weeks']} weeks)")
        print(f"Confidence Level: {estimate['confidence_level']}")
        print()
    
    print("=" * 70)
    print("All estimates generated successfully!")
    print("=" * 70)


if __name__ == "__main__":
    main()
