# GROKSTMATE Examples

This directory contains example scripts demonstrating GROKSTMATE capabilities.

## Available Examples

1. **basic_estimation.py** - Simple cost estimation example
2. **project_workflow.py** - Complete project workflow from estimation to completion
3. **bot_swarm.py** - Deploy and orchestrate multiple bots

## Running Examples

```bash
# Make sure GROKSTMATE is installed
pip install -e .

# Run any example
python examples/basic_estimation.py
python examples/project_workflow.py
python examples/bot_swarm.py
```
