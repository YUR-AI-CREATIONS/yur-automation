# React Frontend Integration Guide

## Quick Start

### 1. Configure Backend URL

Create a `.env` file in your React app root:

```bash
REACT_APP_BACKEND_URL=http://localhost:8000
```

### 2. Start the Backend

```bash
# In the GROKSTMATE directory
./start-backend.sh

# Or manually:
uvicorn grokstmate.api.main:app --host 0.0.0.0 --port 8000
```

### 3. Start Your React App

```bash
# In your React app directory
npm start
```

Your React app (localhost:3003) can now connect to the backend (localhost:8000).

## API Endpoints

### Base URL
```
http://localhost:8000
```

### Available Endpoints

#### Health Check
```javascript
fetch('http://localhost:8000/health')
  .then(res => res.json())
  .then(data => console.log(data));
```

#### Cost Estimation
```javascript
fetch('http://localhost:8000/api/v1/estimate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: "Office Building",
    type: "commercial",
    size: 5000,
    complexity: "moderate"
  })
})
.then(res => res.json())
.then(estimate => console.log(estimate));
```

#### Create Project
```javascript
fetch('http://localhost:8000/api/v1/projects', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: "New Project",
    type: "residential",
    size: 2000
  })
})
.then(res => res.json())
.then(project => console.log(project));
```

#### Deploy Bots
```javascript
fetch('http://localhost:8000/api/v1/bots/deploy', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    bot_type: "construction_bot",
    count: 3,
    capabilities: ["autonomous_operation"]
  })
})
.then(res => res.json())
.then(result => console.log(result));
```

#### Create Agent
```javascript
fetch('http://localhost:8000/api/v1/agents', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    agent_id: "agent_001",
    name: "Construction Manager",
    domain: "construction",
    capabilities: ["estimation", "scheduling"],
    autonomy_level: "fully-autonomous"
  })
})
.then(res => res.json())
.then(agent => console.log(agent));
```

## React Integration Example

```javascript
// src/services/grokstmate.js
const API_BASE = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8000';

export const grokstmateAPI = {
  // Estimate costs
  async estimateProject(projectSpec) {
    const response = await fetch(`${API_BASE}/api/v1/estimate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(projectSpec)
    });
    return response.json();
  },

  // Create project
  async createProject(projectSpec) {
    const response = await fetch(`${API_BASE}/api/v1/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(projectSpec)
    });
    return response.json();
  },

  // Deploy bots
  async deployBots(botType, count = 1) {
    const response = await fetch(`${API_BASE}/api/v1/bots/deploy`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        bot_type: botType,
        count: count,
        capabilities: ["autonomous_operation"]
      })
    });
    return response.json();
  },

  // Get system status
  async getStatus() {
    const response = await fetch(`${API_BASE}/api/status`);
    return response.json();
  },

  // Health check
  async healthCheck() {
    const response = await fetch(`${API_BASE}/health`);
    return response.json();
  }
};
```

## Usage in React Component

```javascript
import React, { useState, useEffect } from 'react';
import { grokstmateAPI } from './services/grokstmate';

function ProjectEstimator() {
  const [estimate, setEstimate] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleEstimate = async () => {
    setLoading(true);
    try {
      const result = await grokstmateAPI.estimateProject({
        name: "My Project",
        type: "commercial",
        size: 5000,
        complexity: "moderate"
      });
      setEstimate(result);
    } catch (error) {
      console.error('Estimation failed:', error);
    }
    setLoading(false);
  };

  return (
    <div>
      <button onClick={handleEstimate} disabled={loading}>
        {loading ? 'Estimating...' : 'Get Estimate'}
      </button>
      {estimate && (
        <div>
          <h3>Total Estimate: ${estimate.total_estimate.toLocaleString()}</h3>
          <p>Timeline: {estimate.timeline_estimate.duration_days} days</p>
        </div>
      )}
    </div>
  );
}
```

## Production Deployment

### For yur-ai.com or yur-ai.store:

1. Update `.env` in React app:
```bash
REACT_APP_BACKEND_URL=https://api.yur-ai.com
```

2. Deploy backend to your server

3. Backend is configured with CORS for:
   - localhost:3003 (development)
   - yur-ai.com (production)
   - yur-ai.store (production)

## Troubleshooting

### CORS Errors
Make sure the backend is running and CORS is properly configured. The backend supports:
- http://localhost:3000
- http://localhost:3003
- https://yur-ai.store
- https://yur-ai.com

### Connection Refused
Ensure the backend is running on port 8000:
```bash
./start-backend.sh
```

### manifest.json Error
Check that your React app's `public/manifest.json` is valid JSON.

## Full API Documentation

See [API.md](docs/API.md) for complete endpoint documentation.
