"""
FastAPI REST API for GROKSTMATE.

Provides HTTP endpoints for accessing autonomous construction capabilities.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

from grokstmate.agents.task_agent import TaskAgent
from grokstmate.estimating.cost_estimator import CostEstimator
from grokstmate.project_management.project_manager import ProjectManager, ProjectStatus
from grokstmate.bot_deployment.bot_manager import BotDeploymentManager, BotType

app = FastAPI(
    title="GROKSTMATE API",
    description="Autonomous Agentic Construction Estimating and Project Management API",
    version="0.1.0",
)

# Configure CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3003",
        "https://yur-ai.store",
        "https://yur-ai.com",
        "https://www.yur-ai.store",
        "https://www.yur-ai.com",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global instances (in production, use dependency injection)
bot_manager = BotDeploymentManager()
projects: Dict[str, ProjectManager] = {}
agents: Dict[str, TaskAgent] = {}


# Request/Response Models
class ProjectSpecification(BaseModel):
    name: str
    type: str = "residential"
    size: int = 1000
    complexity: str = "moderate"
    location: Optional[str] = None


class TaskSpecification(BaseModel):
    task_id: str
    type: str
    description: str
    parameters: Optional[Dict[str, Any]] = None


class BotDeploymentRequest(BaseModel):
    bot_type: str
    count: int = 1
    capabilities: List[str] = []
    config: Optional[Dict[str, Any]] = None


class AgentCreationRequest(BaseModel):
    agent_id: str
    name: str
    domain: str
    capabilities: List[str]
    autonomy_level: str = "supervised"


# Health check
@app.get("/")
async def root():
    """API root endpoint."""
    return {
        "name": "GROKSTMATE API",
        "version": "0.1.0",
        "description": "Autonomous Agentic Construction & Project Management",
        "status": "operational",
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "components": {
            "estimator": "operational",
            "project_manager": "operational",
            "bot_deployment": "operational",
            "agents": "operational",
        },
    }


# Estimation endpoints
@app.post("/api/v1/estimate")
async def create_estimate(spec: ProjectSpecification):
    """
    Generate a cost estimate for a construction project.
    
    Returns detailed cost breakdown, timeline, and confidence level.
    """
    estimator = CostEstimator()
    
    project_spec = spec.dict()
    estimate = estimator.estimate_project(project_spec)
    
    return estimate


# Project management endpoints
@app.post("/api/v1/projects")
async def create_project(spec: ProjectSpecification):
    """
    Create a new construction project with autonomous planning.
    
    Returns complete project plan with tasks, timeline, and resources.
    """
    project_id = f"proj_{len(projects)}_{datetime.now(timezone.utc).timestamp()}"
    
    pm = ProjectManager(project_id, spec.name)
    projects[project_id] = pm
    
    project_spec = spec.dict()
    plan = pm.create_project_plan(project_spec)
    
    return plan


@app.get("/api/v1/projects/{project_id}")
async def get_project(project_id: str):
    """Get project details."""
    if project_id not in projects:
        raise HTTPException(status_code=404, detail="Project not found")
    
    pm = projects[project_id]
    return {
        "project_id": pm.project_id,
        "project_name": pm.project_name,
        "status": pm.status.value,
        "tasks": pm.tasks,
        "milestones": pm.milestones,
    }


@app.get("/api/v1/projects/{project_id}/progress")
async def get_project_progress(project_id: str):
    """Get project progress status."""
    if project_id not in projects:
        raise HTTPException(status_code=404, detail="Project not found")
    
    pm = projects[project_id]
    return pm.track_progress()


@app.get("/api/v1/projects/{project_id}/health")
async def get_project_health(project_id: str):
    """Get project health assessment."""
    if project_id not in projects:
        raise HTTPException(status_code=404, detail="Project not found")
    
    pm = projects[project_id]
    return pm.assess_project_health()


@app.get("/api/v1/projects")
async def list_projects():
    """List all projects."""
    return {
        "projects": [
            {
                "project_id": pm.project_id,
                "project_name": pm.project_name,
                "status": pm.status.value,
            }
            for pm in projects.values()
        ],
        "total": len(projects),
    }


# Bot deployment endpoints
@app.post("/api/v1/bots/deploy")
async def deploy_bots(request: BotDeploymentRequest):
    """
    Deploy autonomous bots for various tasks.
    
    Supports deployment of single bots or swarms.
    """
    bot_type_map = {
        "estimation_bot": BotType.ESTIMATION_BOT,
        "construction_bot": BotType.CONSTRUCTION_BOT,
        "software_builder_bot": BotType.SOFTWARE_BUILDER_BOT,
        "project_monitor_bot": BotType.PROJECT_MONITOR_BOT,
        "resource_allocator_bot": BotType.RESOURCE_ALLOCATOR_BOT,
        "qa_bot": BotType.QUALITY_ASSURANCE_BOT,
    }
    
    bot_type = bot_type_map.get(request.bot_type)
    if not bot_type:
        raise HTTPException(status_code=400, detail=f"Invalid bot type: {request.bot_type}")
    
    bot_ids = await bot_manager.deploy_swarm(
        bot_type,
        request.count,
        request.capabilities,
        request.config
    )
    
    return {
        "deployed_bots": bot_ids,
        "count": len(bot_ids),
        "bot_type": request.bot_type,
    }


@app.get("/api/v1/bots")
async def list_bots():
    """List all active bots."""
    return {
        "bots": bot_manager.get_active_bots(),
        "stats": bot_manager.get_bot_stats(),
    }


@app.post("/api/v1/bots/{bot_id}/execute")
async def execute_with_bot(bot_id: str, task: TaskSpecification):
    """Execute a task using a specific bot."""
    try:
        result = await bot_manager.execute_with_bot(bot_id, task.dict())
        return result
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.delete("/api/v1/bots/{bot_id}")
async def terminate_bot(bot_id: str):
    """Terminate a bot."""
    bot_manager.terminate_bot(bot_id)
    return {"status": "terminated", "bot_id": bot_id}


# Agent endpoints
@app.post("/api/v1/agents")
async def create_agent(request: AgentCreationRequest):
    """
    Create an autonomous task agent.
    
    Agents can make autonomous decisions and execute tasks independently.
    """
    agent = TaskAgent(
        agent_id=request.agent_id,
        name=request.name,
        domain=request.domain,
        capabilities=request.capabilities,
        autonomy_level=request.autonomy_level
    )
    
    agents[request.agent_id] = agent
    
    return {
        "agent_id": agent.agent_id,
        "name": agent.name,
        "domain": agent.domain,
        "autonomy_level": agent.autonomy_level,
        "status": "created",
    }


@app.post("/api/v1/agents/{agent_id}/execute")
async def execute_agent_task(agent_id: str, task: TaskSpecification):
    """Execute a task using a specific agent."""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    agent = agents[agent_id]
    result = await agent.execute_task(task.dict())
    
    return result


@app.post("/api/v1/agents/{agent_id}/decide")
async def agent_make_decision(agent_id: str, context: Dict[str, Any]):
    """Request an autonomous decision from an agent."""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    agent = agents[agent_id]
    decision = await agent.make_decision(context)
    
    return decision


@app.get("/api/v1/agents/{agent_id}")
async def get_agent(agent_id: str):
    """Get agent information."""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    agent = agents[agent_id]
    return agent.get_info()


@app.get("/api/v1/agents")
async def list_agents():
    """List all agents."""
    return {
        "agents": [agent.get_info() for agent in agents.values()],
        "total": len(agents),
    }


# Statistics endpoint
@app.get("/api/v1/stats")
async def get_system_stats():
    """Get overall system statistics."""
    return {
        "projects": len(projects),
        "agents": len(agents),
        "bots": bot_manager.get_bot_stats(),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
