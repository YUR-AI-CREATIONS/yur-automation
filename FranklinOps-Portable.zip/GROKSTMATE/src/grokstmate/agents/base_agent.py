"""
Base Agent Framework for GROKSTMATE

This module provides the foundational agent class that all autonomous agents inherit from.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import logging

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Base class for all autonomous agents in the GROKSTMATE system.
    
    Agents are autonomous entities that can:
    - Make decisions based on context
    - Execute tasks independently
    - Communicate with other agents
    - Learn from outcomes
    """
    
    def __init__(self, agent_id: str, name: str, capabilities: List[str]):
        """
        Initialize a base agent.
        
        Args:
            agent_id: Unique identifier for the agent
            name: Human-readable name
            capabilities: List of capabilities this agent possesses
        """
        self.agent_id = agent_id
        self.name = name
        self.capabilities = capabilities
        self.status = "initialized"
        self.created_at = datetime.now(timezone.utc)
        self.tasks_completed = 0
        self.context: Dict[str, Any] = {}
        
    @abstractmethod
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a task autonomously.
        
        Args:
            task: Task definition containing instructions and context
            
        Returns:
            Result of task execution including status and output
        """
        pass
    
    @abstractmethod
    async def make_decision(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make an autonomous decision based on provided context.
        
        Args:
            context: Decision context and available options
            
        Returns:
            Decision made and reasoning
        """
        pass
    
    async def communicate(self, target_agent_id: str, message: Dict[str, Any]) -> None:
        """
        Send a message to another agent.
        
        Note: This is a placeholder implementation. In production, this would:
        - Use a message queue (e.g., RabbitMQ, Redis)
        - Implement an event bus for agent communication
        - Support synchronous and asynchronous messaging
        - Handle message routing and delivery confirmation
        
        Args:
            target_agent_id: ID of the target agent
            message: Message to send
        """
        logger.info(f"Agent {self.agent_id} communicating with {target_agent_id}")
        # Production: Implement actual message passing
        # message_queue.publish(target_agent_id, message)
        # or event_bus.emit(f"agent.{target_agent_id}", message)
        
    def update_status(self, status: str) -> None:
        """Update agent status."""
        self.status = status
        logger.info(f"Agent {self.agent_id} status updated to: {status}")
        
    def log_task_completion(self) -> None:
        """Log completion of a task."""
        self.tasks_completed += 1
        
    def get_info(self) -> Dict[str, Any]:
        """Get agent information."""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "capabilities": self.capabilities,
            "status": self.status,
            "tasks_completed": self.tasks_completed,
            "created_at": self.created_at.isoformat(),
        }
