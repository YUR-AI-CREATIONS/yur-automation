"""
Project Manager - Autonomous project management system.

Manages construction projects end-to-end with autonomous decision-making,
resource allocation, and progress tracking.
"""

from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta, timezone
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class ProjectStatus(Enum):
    """Project status enumeration."""
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class ProjectManager:
    """
    Autonomous project management system.
    
    Capabilities:
    - Project planning and scheduling
    - Resource allocation and tracking
    - Progress monitoring
    - Risk management
    - Stakeholder communication
    - Autonomous decision-making
    """
    
    def __init__(self, project_id: str, project_name: str):
        """
        Initialize project manager.
        
        Args:
            project_id: Unique project identifier
            project_name: Project name
        """
        self.project_id = project_id
        self.project_name = project_name
        self.status = ProjectStatus.PLANNED
        self.created_at = datetime.now(timezone.utc)
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.resources: Dict[str, Any] = {}
        self.milestones: List[Dict[str, Any]] = []
        self.risks: List[Dict[str, Any]] = []
        
    def create_project_plan(self, project_spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create comprehensive project plan.
        
        Args:
            project_spec: Project specification
            
        Returns:
            Complete project plan
        """
        logger.info(f"Creating project plan for {self.project_name}")
        
        # Generate tasks from project spec
        tasks = self._generate_tasks(project_spec)
        
        # Allocate resources
        resource_plan = self._allocate_resources(tasks)
        
        # Create timeline
        timeline = self._create_timeline(tasks)
        
        # Identify milestones
        milestones = self._identify_milestones(tasks)
        
        # Assess risks
        risks = self._assess_risks(project_spec, tasks)
        
        return {
            "project_id": self.project_id,
            "project_name": self.project_name,
            "tasks": tasks,
            "resource_plan": resource_plan,
            "timeline": timeline,
            "milestones": milestones,
            "risks": risks,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
    
    def track_progress(self) -> Dict[str, Any]:
        """
        Track and report project progress.
        
        Returns:
            Current progress status
        """
        completed_tasks = sum(1 for t in self.tasks.values() if t.get("status") == "completed")
        total_tasks = len(self.tasks)
        
        completion_percentage = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        # Check if any milestones are at risk
        at_risk_milestones = [m for m in self.milestones if self._is_milestone_at_risk(m)]
        
        return {
            "project_id": self.project_id,
            "status": self.status.value,
            "completion_percentage": completion_percentage,
            "completed_tasks": completed_tasks,
            "total_tasks": total_tasks,
            "at_risk_milestones": at_risk_milestones,
            "current_phase": self._get_current_phase(),
            "as_of": datetime.now(timezone.utc).isoformat(),
        }
    
    def allocate_resource(
        self, resource_type: str, resource_spec: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Autonomously allocate resources to project.
        
        Args:
            resource_type: Type of resource (labor, equipment, material)
            resource_spec: Resource specification
            
        Returns:
            Allocation result
        """
        logger.info(f"Allocating {resource_type} resource to project {self.project_id}")
        
        resource_id = f"{resource_type}_{len(self.resources)}"
        
        allocation = {
            "resource_id": resource_id,
            "type": resource_type,
            "spec": resource_spec,
            "allocated_at": datetime.now(timezone.utc).isoformat(),
            "status": "allocated",
        }
        
        self.resources[resource_id] = allocation
        
        return allocation
    
    def add_task(self, task: Dict[str, Any]) -> str:
        """
        Add a task to the project.
        
        Args:
            task: Task specification
            
        Returns:
            Task ID
        """
        task_id = task.get("task_id", f"task_{len(self.tasks)}")
        
        task_data = {
            **task,
            "task_id": task_id,
            "project_id": self.project_id,
            "status": "pending",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        
        self.tasks[task_id] = task_data
        logger.info(f"Added task {task_id} to project {self.project_id}")
        
        return task_id
    
    def update_task_status(self, task_id: str, status: str) -> None:
        """Update task status."""
        if task_id in self.tasks:
            self.tasks[task_id]["status"] = status
            self.tasks[task_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
            logger.info(f"Task {task_id} status updated to {status}")
    
    def add_milestone(self, milestone: Dict[str, Any]) -> None:
        """Add a project milestone."""
        milestone["created_at"] = datetime.now(timezone.utc).isoformat()
        self.milestones.append(milestone)
        logger.info(f"Added milestone: {milestone.get('name', 'Unnamed')}")
    
    def assess_project_health(self) -> Dict[str, Any]:
        """
        Assess overall project health autonomously.
        
        Returns:
            Project health assessment
        """
        progress = self.track_progress()
        
        # Health indicators
        on_schedule = progress["completion_percentage"] >= self._expected_completion()
        at_risk_count = len(progress["at_risk_milestones"])
        resource_utilization = self._calculate_resource_utilization()
        
        # Overall health score (0-100)
        health_score = 100
        if not on_schedule:
            health_score -= 20
        health_score -= min(at_risk_count * 10, 30)
        health_score -= (100 - resource_utilization) * 0.2
        
        # Determine health status
        if health_score >= 80:
            health_status = "excellent"
        elif health_score >= 60:
            health_status = "good"
        elif health_score >= 40:
            health_status = "fair"
        else:
            health_status = "poor"
        
        return {
            "project_id": self.project_id,
            "health_status": health_status,
            "health_score": max(0, health_score),
            "on_schedule": on_schedule,
            "at_risk_milestones": at_risk_count,
            "resource_utilization": resource_utilization,
            "recommendations": self._generate_recommendations(health_status),
        }
    
    def _generate_tasks(self, project_spec: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """Generate tasks based on project specification."""
        # Standard construction project tasks
        standard_tasks = [
            {"name": "Site preparation", "duration_days": 5, "dependencies": []},
            {"name": "Foundation", "duration_days": 10, "dependencies": ["Site preparation"]},
            {"name": "Framing", "duration_days": 15, "dependencies": ["Foundation"]},
            {"name": "MEP rough-in", "duration_days": 12, "dependencies": ["Framing"]},
            {"name": "Insulation", "duration_days": 5, "dependencies": ["MEP rough-in"]},
            {"name": "Drywall", "duration_days": 8, "dependencies": ["Insulation"]},
            {"name": "Finishes", "duration_days": 15, "dependencies": ["Drywall"]},
            {"name": "Final inspection", "duration_days": 2, "dependencies": ["Finishes"]},
        ]
        
        tasks = {}
        for i, task in enumerate(standard_tasks):
            task_id = f"task_{i}"
            tasks[task_id] = {
                "task_id": task_id,
                **task,
                "status": "pending",
            }
        
        return tasks
    
    def _allocate_resources(self, tasks: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Create resource allocation plan."""
        return {
            "labor": {"workers": 10, "supervisors": 2},
            "equipment": ["excavator", "crane", "scaffolding"],
            "budget_allocated": 500000,
        }
    
    def _create_timeline(self, tasks: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Create project timeline."""
        total_days = sum(t.get("duration_days", 0) for t in tasks.values())
        
        return {
            "start_date": datetime.now(timezone.utc).isoformat(),
            "estimated_end_date": (datetime.now(timezone.utc) + timedelta(days=total_days)).isoformat(),
            "total_duration_days": total_days,
        }
    
    def _identify_milestones(self, tasks: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Identify key project milestones."""
        return [
            {"name": "Foundation Complete", "task": "Foundation"},
            {"name": "Structure Enclosed", "task": "Framing"},
            {"name": "MEP Complete", "task": "MEP rough-in"},
            {"name": "Project Complete", "task": "Final inspection"},
        ]
    
    def _assess_risks(
        self, project_spec: Dict[str, Any], tasks: Dict[str, Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Assess project risks."""
        return [
            {
                "risk": "Weather delays",
                "probability": "medium",
                "impact": "medium",
                "mitigation": "Build buffer time into schedule",
            },
            {
                "risk": "Supply chain disruptions",
                "probability": "low",
                "impact": "high",
                "mitigation": "Pre-order critical materials",
            },
            {
                "risk": "Labor shortage",
                "probability": "medium",
                "impact": "high",
                "mitigation": "Maintain relationships with multiple subcontractors",
            },
        ]
    
    def _is_milestone_at_risk(self, milestone: Dict[str, Any]) -> bool:
        """
        Check if milestone is at risk.
        
        Note: This is a placeholder implementation. In production, this would:
        - Compare current progress to expected progress
        - Check dependent task delays
        - Assess resource availability
        - Consider external risk factors
        """
        # Production: Implement actual risk detection based on project metrics
        return False
    
    def _get_current_phase(self) -> str:
        """Get current project phase."""
        if self.status == ProjectStatus.PLANNED:
            return "Planning"
        elif self.status == ProjectStatus.IN_PROGRESS:
            return "Execution"
        else:
            return self.status.value.title()
    
    def _expected_completion(self) -> float:
        """
        Calculate expected completion percentage at this point.
        
        Note: This is a placeholder implementation. In production, this would:
        - Calculate based on elapsed time vs total timeline
        - Factor in critical path completion
        - Adjust for actual vs planned velocity
        - Consider resource efficiency
        """
        # Production: Calculate based on (days_elapsed / total_days) * 100
        return 50.0
    
    def _calculate_resource_utilization(self) -> float:
        """
        Calculate resource utilization percentage.
        
        Note: This is a placeholder implementation. In production, this would:
        - Track actual resource hours vs available hours
        - Monitor equipment usage rates
        - Calculate material consumption efficiency
        - Measure productivity metrics
        """
        # Production: Calculate (resources_used / resources_allocated) * 100
        return 85.0
    
    def _generate_recommendations(self, health_status: str) -> List[str]:
        """Generate recommendations based on health status."""
        if health_status == "poor":
            return [
                "Immediate review of critical path tasks",
                "Consider additional resources",
                "Escalate to stakeholders",
            ]
        elif health_status == "fair":
            return [
                "Monitor at-risk tasks closely",
                "Review resource allocation",
            ]
        else:
            return ["Continue current approach", "Maintain communication with stakeholders"]
