"""
Command Line Interface for GROKSTMATE.

Provides CLI commands for interacting with the autonomous construction software.
"""

import click
import asyncio
import json
from rich.console import Console
from rich.table import Table
from rich import print as rprint

from grokstmate.agents.task_agent import TaskAgent
from grokstmate.estimating.cost_estimator import CostEstimator
from grokstmate.project_management.project_manager import ProjectManager
from grokstmate.bot_deployment.bot_manager import BotDeploymentManager, BotType

console = Console()


@click.group()
@click.version_option(version="0.1.0")
def main():
    """
    GROKSTMATE - Autonomous Agentic Construction & Project Management Software
    
    The world's first end-to-end fully autonomous agentic construction estimating
    and project management software.
    """
    pass


@main.command()
@click.option("--type", default="residential", help="Project type")
@click.option("--size", default=2000, type=int, help="Project size (sq ft)")
@click.option("--complexity", default="moderate", help="Project complexity")
@click.option("--name", default="New Project", help="Project name")
def estimate(type, size, complexity, name):
    """Generate a cost estimate for a construction project."""
    console.print(f"\n[bold cyan]Estimating project: {name}[/bold cyan]\n")
    
    estimator = CostEstimator()
    
    project_spec = {
        "name": name,
        "type": type,
        "size": size,
        "complexity": complexity,
    }
    
    estimate_result = estimator.estimate_project(project_spec)
    
    # Display results
    console.print(f"[bold]Project:[/bold] {estimate_result['project_name']}")
    console.print(f"[bold]Type:[/bold] {estimate_result['project_type']}")
    console.print(f"[bold]Size:[/bold] {size} sq ft")
    console.print(f"[bold]Complexity:[/bold] {complexity}\n")
    
    # Breakdown table
    table = Table(title="Cost Breakdown")
    table.add_column("Category", style="cyan")
    table.add_column("Amount", style="green", justify="right")
    
    breakdown = estimate_result['breakdown']
    table.add_row("Materials", f"${breakdown['materials']['total']:,.2f}")
    table.add_row("Labor", f"${breakdown['labor']['total']:,.2f}")
    table.add_row("Equipment", f"${breakdown['equipment']['total']:,.2f}")
    table.add_row("Overhead", f"${breakdown['overhead']['total']:,.2f}")
    table.add_row("Subtotal", f"${estimate_result['subtotal']:,.2f}")
    table.add_row("Contingency", f"${estimate_result['contingency']:,.2f}")
    table.add_row("[bold]TOTAL ESTIMATE[/bold]", f"[bold]${estimate_result['total_estimate']:,.2f}[/bold]")
    
    console.print(table)
    
    timeline = estimate_result['timeline_estimate']
    console.print(f"\n[bold]Timeline:[/bold] {timeline['duration_days']} days ({timeline['duration_weeks']} weeks)")
    console.print(f"[bold]Confidence:[/bold] {estimate_result['confidence_level']}\n")


@main.command()
@click.option("--project-id", default="proj_001", help="Project ID")
@click.option("--name", default="Construction Project", help="Project name")
def create_project(project_id, name):
    """Create a new construction project."""
    console.print(f"\n[bold cyan]Creating project: {name}[/bold cyan]\n")
    
    pm = ProjectManager(project_id, name)
    
    project_spec = {
        "type": "commercial",
        "size": 5000,
        "complexity": "moderate",
    }
    
    plan = pm.create_project_plan(project_spec)
    
    console.print(f"[bold]Project ID:[/bold] {plan['project_id']}")
    console.print(f"[bold]Project Name:[/bold] {plan['project_name']}")
    console.print(f"[bold]Total Tasks:[/bold] {len(plan['tasks'])}")
    
    timeline = plan['timeline']
    console.print(f"[bold]Start Date:[/bold] {timeline['start_date'][:10]}")
    console.print(f"[bold]Duration:[/bold] {timeline['total_duration_days']} days\n")
    
    # Milestones
    table = Table(title="Project Milestones")
    table.add_column("Milestone", style="cyan")
    table.add_column("Linked Task", style="yellow")
    
    for milestone in plan['milestones']:
        table.add_row(milestone['name'], milestone['task'])
    
    console.print(table)
    console.print("\n[green]✓ Project created successfully[/green]\n")


@main.command()
@click.option("--bot-type", default="construction_bot", help="Type of bot to deploy")
@click.option("--count", default=1, type=int, help="Number of bots to deploy")
def deploy_bot(bot_type, count):
    """Deploy autonomous bots."""
    console.print(f"\n[bold cyan]Deploying {count} {bot_type}(s)[/bold cyan]\n")
    
    manager = BotDeploymentManager()
    
    # Map string to BotType enum
    bot_type_map = {
        "estimation_bot": BotType.ESTIMATION_BOT,
        "construction_bot": BotType.CONSTRUCTION_BOT,
        "software_builder_bot": BotType.SOFTWARE_BUILDER_BOT,
        "project_monitor_bot": BotType.PROJECT_MONITOR_BOT,
    }
    
    bot_type_enum = bot_type_map.get(bot_type, BotType.CONSTRUCTION_BOT)
    
    # Deploy bots
    bot_ids = asyncio.run(
        manager.deploy_swarm(bot_type_enum, count, ["autonomous_operation"], {})
    )
    
    console.print(f"[green]✓ Successfully deployed {len(bot_ids)} bot(s)[/green]\n")
    
    # Show deployed bots
    table = Table(title="Deployed Bots")
    table.add_column("Bot ID", style="cyan")
    table.add_column("Type", style="yellow")
    table.add_column("Status", style="green")
    
    for bot_id in bot_ids:
        table.add_row(bot_id, bot_type, "active")
    
    console.print(table)
    console.print()


@main.command()
@click.option("--agent-id", default="agent_001", help="Agent ID")
@click.option("--name", default="Task Agent 1", help="Agent name")
@click.option("--domain", default="construction", help="Agent domain")
def create_agent(agent_id, name, domain):
    """Create an autonomous task agent."""
    console.print(f"\n[bold cyan]Creating autonomous agent: {name}[/bold cyan]\n")
    
    agent = TaskAgent(
        agent_id=agent_id,
        name=name,
        domain=domain,
        capabilities=["estimation", "project_management", "autonomous_decision"],
        autonomy_level="fully-autonomous"
    )
    
    info = agent.get_info()
    
    console.print(f"[bold]Agent ID:[/bold] {info['agent_id']}")
    console.print(f"[bold]Name:[/bold] {info['name']}")
    console.print(f"[bold]Domain:[/bold] {domain}")
    console.print(f"[bold]Autonomy Level:[/bold] fully-autonomous")
    console.print(f"[bold]Capabilities:[/bold]")
    for cap in info['capabilities']:
        console.print(f"  • {cap}")
    
    console.print("\n[green]✓ Agent created successfully[/green]\n")


@main.command()
def demo():
    """Run a complete demonstration of GROKSTMATE capabilities."""
    console.print("\n[bold magenta]═══════════════════════════════════════════════════════════[/bold magenta]")
    console.print("[bold magenta]  GROKSTMATE AUTONOMOUS CONSTRUCTION SOFTWARE DEMO[/bold magenta]")
    console.print("[bold magenta]═══════════════════════════════════════════════════════════[/bold magenta]\n")
    
    # Step 1: Create estimation
    console.print("[bold cyan]Step 1: Autonomous Cost Estimation[/bold cyan]")
    estimator = CostEstimator()
    estimate = estimator.estimate_project({
        "name": "Commercial Building",
        "type": "commercial",
        "size": 10000,
        "complexity": "complex",
    })
    console.print(f"✓ Estimated cost: ${estimate['total_estimate']:,.2f}")
    console.print(f"✓ Timeline: {estimate['timeline_estimate']['duration_days']} days\n")
    
    # Step 2: Create project
    console.print("[bold cyan]Step 2: Create Project Plan[/bold cyan]")
    pm = ProjectManager("demo_project", "Demo Commercial Building")
    plan = pm.create_project_plan({
        "type": "commercial",
        "size": 10000,
        "complexity": "complex",
    })
    console.print(f"✓ Project created with {len(plan['tasks'])} tasks")
    console.print(f"✓ {len(plan['milestones'])} milestones identified\n")
    
    # Step 3: Deploy bots
    console.print("[bold cyan]Step 3: Deploy Autonomous Bots[/bold cyan]")
    bot_manager = BotDeploymentManager()
    bot_ids = asyncio.run(
        bot_manager.deploy_swarm(BotType.CONSTRUCTION_BOT, 3, ["construction_mgmt"], {})
    )
    console.print(f"✓ Deployed {len(bot_ids)} construction bots\n")
    
    # Step 4: Create agent
    console.print("[bold cyan]Step 4: Create Autonomous Agent[/bold cyan]")
    agent = TaskAgent(
        "demo_agent",
        "Demo Construction Agent",
        "construction",
        ["estimation", "scheduling", "resource_allocation"],
        "fully-autonomous"
    )
    console.print(f"✓ Agent '{agent.name}' created with full autonomy\n")
    
    # Step 5: Execute task with agent
    console.print("[bold cyan]Step 5: Execute Autonomous Task[/bold cyan]")
    task_result = asyncio.run(agent.execute_task({
        "task_id": "demo_task_1",
        "type": "estimation",
        "description": "Estimate foundation costs",
    }))
    console.print(f"✓ Task executed: {task_result['status']}\n")
    
    # Summary
    console.print("[bold green]═══════════════════════════════════════════════════════════[/bold green]")
    console.print("[bold green]  DEMO COMPLETE - All Systems Operational[/bold green]")
    console.print("[bold green]═══════════════════════════════════════════════════════════[/bold green]\n")
    
    stats = {
        "Estimations Generated": 1,
        "Projects Managed": 1,
        "Bots Deployed": len(bot_ids),
        "Agents Active": 1,
        "Tasks Completed": 1,
    }
    
    table = Table(title="System Status")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green", justify="right")
    
    for key, value in stats.items():
        table.add_row(key, str(value))
    
    console.print(table)
    console.print()


@main.command()
def web():
    """Launch the interactive web UI to see agents in action."""
    console.print("\n[bold cyan]🌐 Starting GROKSTMATE Web UI...[/bold cyan]\n")
    console.print("[bold]The web interface shows:[/bold]")
    console.print("  • Live agents working in real-time")
    console.print("  • Visual workflow execution")
    console.print("  • Bot deployment and orchestration")
    console.print("  • Real-time event streaming\n")
    console.print("[bold green]➜[/bold green] Open your browser to: [bold]http://localhost:8080[/bold]")
    console.print("[bold yellow]Press Ctrl+C to stop the server[/bold yellow]\n")
    
    import uvicorn
    from grokstmate.web_ui.app import app
    
    try:
        uvicorn.run(app, host="0.0.0.0", port=8080, log_level="info")
    except KeyboardInterrupt:
        console.print("\n[bold cyan]Web UI stopped.[/bold cyan]\n")


if __name__ == "__main__":
    main()
