"""
Web UI for GROKSTMATE - Interactive Agent and Workflow Visualization

This module provides a real-time web interface showing agents in action,
workflow execution, and live system monitoring.
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi import Request
import asyncio
import json
from datetime import datetime, timezone
from typing import List, Dict, Any
import os

from ..agents.task_agent import TaskAgent
from ..estimating.cost_estimator import CostEstimator
from ..project_management.project_manager import ProjectManager
from ..bot_deployment.bot_manager import BotDeploymentManager, BotType

# Get the directory of this file
current_dir = os.path.dirname(os.path.abspath(__file__))

app = FastAPI(title="GROKSTMATE Live Demo")

# Mount static files and templates
app.mount("/static", StaticFiles(directory=os.path.join(current_dir, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(current_dir, "templates"))

# Global state for live demo
active_agents: Dict[str, TaskAgent] = {}
active_bots: Dict[str, Any] = {}
workflow_events: List[Dict[str, Any]] = []
connected_websockets: List[WebSocket] = []


class WorkflowManager:
    """Manages live workflow execution and broadcasting."""
    
    def __init__(self):
        self.running = False
        
    async def broadcast_event(self, event: Dict[str, Any]):
        """Broadcast event to all connected websockets."""
        workflow_events.append(event)
        # Keep only last 100 events
        if len(workflow_events) > 100:
            workflow_events.pop(0)
            
        message = json.dumps(event)
        disconnected = []
        for ws in connected_websockets:
            try:
                await ws.send_text(message)
            except:
                disconnected.append(ws)
        
        # Clean up disconnected websockets
        for ws in disconnected:
            if ws in connected_websockets:
                connected_websockets.remove(ws)
    
    async def run_demo_workflow(self):
        """Run a live demonstration workflow."""
        self.running = True
        
        try:
            # Step 1: Create estimation agent
            await self.broadcast_event({
                "type": "agent_created",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_estimator",
                    "name": "Estimation Agent",
                    "status": "initializing"
                }
            })
            
            agent = TaskAgent(
                "demo_estimator",
                "Estimation Agent",
                "estimation",
                ["cost_estimation", "timeline_prediction"],
                "fully-autonomous"
            )
            active_agents["demo_estimator"] = agent
            
            await asyncio.sleep(1)
            
            await self.broadcast_event({
                "type": "agent_ready",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_estimator",
                    "status": "ready"
                }
            })
            
            # Step 2: Agent executes estimation task
            await self.broadcast_event({
                "type": "task_started",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_estimator",
                    "task_id": "estimate_project_001",
                    "description": "Estimating commercial building costs"
                }
            })
            
            result = await agent.execute_task({
                "task_id": "estimate_project_001",
                "type": "estimation",
                "description": "Estimate commercial building"
            })
            
            await self.broadcast_event({
                "type": "task_completed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_estimator",
                    "task_id": "estimate_project_001",
                    "result": result
                }
            })
            
            await asyncio.sleep(1)
            
            # Step 3: Deploy bot swarm
            await self.broadcast_event({
                "type": "bot_swarm_deploying",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "bot_type": "construction_bot",
                    "count": 3
                }
            })
            
            bot_manager = BotDeploymentManager()
            bot_ids = await bot_manager.deploy_swarm(
                BotType.CONSTRUCTION_BOT,
                3,
                ["construction_management"],
                {}
            )
            
            for bot_id in bot_ids:
                active_bots[bot_id] = bot_manager.bots[bot_id]
                await self.broadcast_event({
                    "type": "bot_deployed",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "data": {
                        "bot_id": bot_id,
                        "bot_type": "construction_bot",
                        "status": "active"
                    }
                })
                await asyncio.sleep(0.5)
            
            # Step 4: Create project manager agent
            await self.broadcast_event({
                "type": "agent_created",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_pm",
                    "name": "Project Manager Agent",
                    "status": "initializing"
                }
            })
            
            pm_agent = TaskAgent(
                "demo_pm",
                "Project Manager Agent",
                "project_management",
                ["planning", "scheduling", "monitoring"],
                "fully-autonomous"
            )
            active_agents["demo_pm"] = pm_agent
            
            await asyncio.sleep(1)
            
            # Step 5: PM agent creates project plan
            await self.broadcast_event({
                "type": "task_started",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_pm",
                    "task_id": "create_plan_001",
                    "description": "Creating project plan"
                }
            })
            
            pm = ProjectManager("demo_project", "Demo Project")
            plan = pm.create_project_plan({
                "type": "commercial",
                "size": 5000,
                "complexity": "moderate"
            })
            
            await self.broadcast_event({
                "type": "task_completed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agent_id": "demo_pm",
                    "task_id": "create_plan_001",
                    "result": {
                        "status": "success",
                        "tasks_created": len(plan["tasks"]),
                        "milestones": len(plan["milestones"])
                    }
                }
            })
            
            # Step 6: Bots execute tasks
            for i, bot_id in enumerate(bot_ids):
                await self.broadcast_event({
                    "type": "bot_task_started",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "data": {
                        "bot_id": bot_id,
                        "task_id": f"bot_task_{i}",
                        "description": f"Processing construction activity {i+1}"
                    }
                })
                
                await asyncio.sleep(1)
                
                await self.broadcast_event({
                    "type": "bot_task_completed",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "data": {
                        "bot_id": bot_id,
                        "task_id": f"bot_task_{i}",
                        "status": "success"
                    }
                })
            
            # Final status
            await self.broadcast_event({
                "type": "workflow_complete",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {
                    "agents_active": len(active_agents),
                    "bots_deployed": len(active_bots),
                    "tasks_completed": 5
                }
            })
            
        except Exception as e:
            await self.broadcast_event({
                "type": "error",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "data": {"error": str(e)}
            })
        
        self.running = False


workflow_manager = WorkflowManager()


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Main dashboard showing live agents and workflow."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/status")
async def get_status():
    """Get current system status."""
    return JSONResponse({
        "agents": {
            agent_id: {
                "name": agent.name,
                "domain": agent.domain,
                "status": agent.status,
                "tasks_completed": agent.tasks_completed
            }
            for agent_id, agent in active_agents.items()
        },
        "bots": {
            bot_id: bot.get_status()
            for bot_id, bot in active_bots.items()
        },
        "workflow_running": workflow_manager.running,
        "event_count": len(workflow_events)
    })


@app.post("/api/start-workflow")
async def start_workflow():
    """Start the demo workflow."""
    if not workflow_manager.running:
        asyncio.create_task(workflow_manager.run_demo_workflow())
        return {"status": "started"}
    return {"status": "already_running"}


@app.get("/api/events")
async def get_events():
    """Get recent workflow events."""
    return JSONResponse({"events": workflow_events[-50:]})


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates."""
    await websocket.accept()
    connected_websockets.append(websocket)
    
    # Send current status
    await websocket.send_text(json.dumps({
        "type": "connected",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "data": {
            "agents": len(active_agents),
            "bots": len(active_bots)
        }
    }))
    
    try:
        while True:
            # Keep connection alive
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))
    except WebSocketDisconnect:
        if websocket in connected_websockets:
            connected_websockets.remove(websocket)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
