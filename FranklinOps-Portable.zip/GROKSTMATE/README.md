# GROKSTMATE 🏗️🤖

**The world's first end-to-end fully autonomous agentic construction estimating and project management software.**

GROKSTMATE can fully deploy task agents and bots to build software and run construction companies with autonomous decision-making capabilities.

---

## 🚀 **QUICK START - See It In Action!**

### For Standalone Demo:

**1. Easy Script (Recommended):**
```bash
# Linux/Mac
./start-web-ui.sh

# Windows
start-web-ui.bat
```

**2. CLI Command:**
```bash
grokstmate web
```

**3. Manual:**
```bash
pip install -e .
python -m uvicorn grokstmate.web_ui.app:app --host 0.0.0.0 --port 8080
```

**Then open:** http://localhost:8080 and click "🚀 Start Autonomous Workflow"

### For React Frontend Integration:

**Start the Backend API:**
```bash
# Linux/Mac
./start-backend.sh

# Windows
start-backend.bat
```

**Configure your React app:**
```bash
# In your React app's .env file:
REACT_APP_BACKEND_URL=http://localhost:8000
```

**Then start your React app** (e.g., on localhost:3003) and it will connect to the backend!

📖 **Integration Guide:** See [REACT_INTEGRATION.md](REACT_INTEGRATION.md) for complete React integration docs

📖 **Having trouble?** See [QUICKSTART.md](QUICKSTART.md) for detailed step-by-step instructions.

---

## 🌟 Features

### Autonomous Agentic System
- **Task Agents**: Fully autonomous agents that can execute construction and software tasks independently
- **Bot Deployment**: Deploy specialized bots for estimation, construction management, and software building
- **Autonomous Decision Making**: AI-powered decision engine that operates without human intervention
- **Multi-Agent Orchestration**: Coordinate multiple agents and bots to handle complex workflows

### Construction Estimating
- **Automated Cost Estimation**: AI-powered cost estimation for materials, labor, equipment, and overhead
- **Timeline Prediction**: Intelligent project timeline estimation based on scope and complexity
- **Risk Assessment**: Autonomous risk identification and mitigation strategies
- **Multi-Project Support**: Handle residential, commercial, and industrial projects

### Project Management
- **Autonomous Planning**: Generate complete project plans with tasks, milestones, and dependencies
- **Resource Allocation**: Intelligent resource assignment and optimization
- **Progress Tracking**: Real-time project monitoring and health assessment
- **Stakeholder Management**: Automated reporting and communication

### Software Building Capabilities
- **Code Generation Agents**: Bots that can build software components autonomously
- **Build Automation**: Automated build pipelines and deployment
- **Quality Assurance**: Automated testing and QA bots

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/YUR-AI-CREATIONS/GROKSTMATE-.git
cd GROKSTMATE-

# Install dependencies
pip install -e .
```

### Basic Usage

#### 🌐 Interactive Web UI (NEW!)

See agents in action with our live web interface:

```bash
# Launch the interactive web demo
grokstmate web

# Then open your browser to: http://localhost:8080
```

**Features:**
- 🎬 Watch agents work in real-time
- 📊 Visual workflow execution with 5 stages
- 🤖 Live agent and bot deployment
- 📋 Real-time event streaming
- 📈 Live statistics dashboard

![GROKSTMATE Web UI](https://github.com/user-attachments/assets/38e6bd5d-9689-479f-ac2f-6729244ab7e9)
*Initial state: Ready to start autonomous workflow*

![GROKSTMATE Web UI Active](https://github.com/user-attachments/assets/7b4c5af9-a005-4017-8fe0-fab90fa830f6)
*Active state: 2 agents deployed, 3 bots working, 5 tasks completed*

#### Command Line Interface

```bash
# Generate a cost estimate
grokstmate estimate --type commercial --size 5000 --complexity moderate --name "Office Building"

# Create a new project
grokstmate create-project --project-id proj_001 --name "New Construction Project"

# Deploy autonomous bots
grokstmate deploy-bot --bot-type construction_bot --count 3

# Create an autonomous agent
grokstmate create-agent --agent-id agent_001 --name "Construction Manager" --domain construction

# Run complete CLI demo
grokstmate demo

# Launch interactive web UI
grokstmate web
```

#### Python API

```python
from grokstmate import CostEstimator, ProjectManager, TaskAgent
from grokstmate.bot_deployment import BotDeploymentManager, BotType

# Cost Estimation
estimator = CostEstimator(region="US", currency="USD")
estimate = estimator.estimate_project({
    "name": "Commercial Building",
    "type": "commercial",
    "size": 10000,
    "complexity": "complex"
})
print(f"Total Estimate: ${estimate['total_estimate']:,.2f}")

# Project Management
pm = ProjectManager("proj_001", "My Construction Project")
plan = pm.create_project_plan({
    "type": "residential",
    "size": 3000,
    "complexity": "moderate"
})
print(f"Created plan with {len(plan['tasks'])} tasks")

# Deploy Bots
bot_manager = BotDeploymentManager()
bot_ids = await bot_manager.deploy_swarm(
    BotType.CONSTRUCTION_BOT, 
    count=5,
    capabilities=["autonomous_operation"],
    config={}
)
print(f"Deployed {len(bot_ids)} construction bots")

# Create Autonomous Agent
agent = TaskAgent(
    agent_id="agent_001",
    name="Construction Manager Agent",
    domain="construction",
    capabilities=["estimation", "scheduling", "resource_allocation"],
    autonomy_level="fully-autonomous"
)

# Execute task with agent
result = await agent.execute_task({
    "task_id": "estimate_foundation",
    "type": "estimation",
    "description": "Estimate foundation costs for new building"
})
print(f"Task Status: {result['status']}")
```

#### REST API

```bash
# Start the API server
uvicorn grokstmate.api.main:app --host 0.0.0.0 --port 8000

# Or using Python
python -m grokstmate.api.main
```

```bash
# Generate estimate
curl -X POST "http://localhost:8000/api/v1/estimate" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Office Building",
    "type": "commercial",
    "size": 5000,
    "complexity": "moderate"
  }'

# Create project
curl -X POST "http://localhost:8000/api/v1/projects" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "New Project",
    "type": "residential",
    "size": 2000
  }'

# Deploy bots
curl -X POST "http://localhost:8000/api/v1/bots/deploy" \
  -H "Content-Type: application/json" \
  -d '{
    "bot_type": "construction_bot",
    "count": 3,
    "capabilities": ["autonomous_operation"]
  }'

# Create agent
curl -X POST "http://localhost:8000/api/v1/agents" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "agent_001",
    "name": "Construction Agent",
    "domain": "construction",
    "capabilities": ["estimation", "scheduling"],
    "autonomy_level": "fully-autonomous"
  }'
```

## 📋 System Architecture

```
GROKSTMATE/
├── agents/               # Autonomous agent framework
│   ├── base_agent.py    # Base agent class
│   └── task_agent.py    # Specialized task agents
├── estimating/          # Cost estimation system
│   └── cost_estimator.py
├── project_management/  # Project management system
│   └── project_manager.py
├── bot_deployment/      # Bot deployment & orchestration
│   └── bot_manager.py
├── api/                 # REST API
│   └── main.py
└── cli.py              # Command line interface
```

## 🤖 Agent Types

### Task Agents
Autonomous agents that can:
- Execute construction estimation tasks
- Manage project workflows
- Build and deploy software
- Make decisions within their domain
- Communicate with other agents

### Bot Types
Specialized bots for specific tasks:
- **Estimation Bot**: Cost and timeline estimation
- **Construction Bot**: Construction activity management
- **Software Builder Bot**: Automated software building
- **Project Monitor Bot**: Real-time project monitoring
- **Resource Allocator Bot**: Resource optimization
- **QA Bot**: Quality assurance and testing

## 💡 Example Use Cases

### 1. Autonomous Cost Estimation
Deploy an estimation bot that analyzes project requirements and generates comprehensive cost estimates without human intervention.

### 2. End-to-End Project Management
Create a project manager that autonomously plans, schedules, allocates resources, and monitors progress throughout the entire project lifecycle.

### 3. Software Building for Construction
Deploy software builder bots that can generate custom tools and applications needed for construction management.

### 4. Multi-Agent Construction Operation
Deploy a swarm of specialized agents that work together to run an entire construction company autonomously.

## 🔧 Configuration

### Environment Variables
```bash
# Optional: Configure AI model providers
OPENAI_API_KEY=your_key_here
ANTHROPIC_API_KEY=your_key_here

# Database configuration
DATABASE_URL=sqlite:///grokstmate.db

# API configuration
API_HOST=0.0.0.0
API_PORT=8000
```

## 📊 Performance

- **Estimation Speed**: Generate comprehensive estimates in seconds
- **Bot Deployment**: Deploy hundreds of bots simultaneously
- **Agent Coordination**: Coordinate complex multi-agent workflows
- **Scalability**: Handle multiple concurrent projects

## 🛠️ Development

### Running Tests
```bash
pytest tests/
```

### Code Structure
- Type-safe Python with Pydantic models
- Async/await for concurrent operations
- Modular architecture for extensibility
- RESTful API design

## 🌐 API Documentation

Once the API server is running, visit:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 📝 License

Copyright © 2024 YUR-AI-CREATIONS

## 🤝 Contributing

This is the world's first fully autonomous agentic construction software. Contributions are welcome to enhance the autonomous capabilities!

## 📧 Contact

For questions or support, please open an issue on GitHub.

---

**Did somebody say lemonade?** 🍋

*When life gives you construction projects, GROKSTMATE makes them autonomous!* 
