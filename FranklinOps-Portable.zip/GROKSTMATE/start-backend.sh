#!/bin/bash
# GROKSTMATE Backend API Startup Script

set -e

echo "=========================================="
echo "  GROKSTMATE Backend API - Easy Start"
echo "=========================================="
echo ""

# Check if we're in the right directory
if [ ! -f "setup.py" ]; then
    echo "❌ Error: Please run this script from the GROKSTMATE root directory"
    exit 1
fi

echo "Step 1: Installing dependencies..."
pip install -q -e . 2>&1 | grep -v "already satisfied" || true
echo "✓ Dependencies installed"
echo ""

echo "Step 2: Starting backend API server..."
echo ""
echo "=========================================="
echo "  🚀 Backend API will be available at:"
echo "  http://localhost:8000"
echo ""
echo "  📚 API Documentation:"
echo "  http://localhost:8000/docs"
echo "=========================================="
echo ""
echo "📌 FOR REACT FRONTEND:"
echo "  Set in your React .env file:"
echo "  REACT_APP_BACKEND_URL=http://localhost:8000"
echo ""
echo "  CORS enabled for:"
echo "  - localhost:3000"
echo "  - localhost:3003"
echo "  - yur-ai.com"
echo "  - yur-ai.store"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
echo "Starting server now..."
echo ""

# Start the backend API
python -m uvicorn grokstmate.api.main:app --host 0.0.0.0 --port 8000 --reload
