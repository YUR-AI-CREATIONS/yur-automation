#!/usr/bin/env python3
"""
Integration test for GROKSTMATE system.
"""

import asyncio
import sys
from grokstmate import CostEstimator, ProjectManager, TaskAgent
from grokstmate.bot_deployment import BotDeploymentManager, BotType


async def test_cost_estimation():
    """Test cost estimation functionality."""
    print("Testing Cost Estimation...")
    
    estimator = CostEstimator(region="US", currency="USD")
    
    project_spec = {
        "name": "Test Project",
        "type": "commercial",
        "size": 5000,
        "complexity": "moderate",
    }
    
    estimate = estimator.estimate_project(project_spec)
    
    assert "total_estimate" in estimate
    assert estimate["total_estimate"] > 0
    
    print("✓ Cost Estimation works correctly")
    return True


async def test_project_management():
    """Test project management functionality."""
    print("Testing Project Management...")
    
    pm = ProjectManager("test_proj_001", "Test Project")
    
    plan = pm.create_project_plan({
        "type": "residential",
        "size": 2000,
        "complexity": "simple",
    })
    
    assert "tasks" in plan
    assert len(plan["tasks"]) > 0
    
    print("✓ Project Management works correctly")
    return True


async def test_task_agents():
    """Test autonomous task agents."""
    print("Testing Task Agents...")
    
    agent = TaskAgent(
        agent_id="test_agent_001",
        name="Test Agent",
        domain="construction",
        capabilities=["estimation", "scheduling"],
        autonomy_level="fully-autonomous"
    )
    
    result = await agent.execute_task({
        "task_id": "test_task_001",
        "type": "estimation",
        "description": "Test task",
    })
    
    assert result["status"] == "success"
    
    print("✓ Task Agents work correctly")
    return True


async def test_bot_deployment():
    """Test bot deployment system."""
    print("Testing Bot Deployment...")
    
    manager = BotDeploymentManager()
    
    bot_id = manager.deploy_bot(
        BotType.CONSTRUCTION_BOT,
        ["autonomous_operation"],
        {}
    )
    
    assert bot_id in manager.bots
    
    print("✓ Bot Deployment works correctly")
    return True


async def run_all_tests():
    """Run all tests."""
    print("=" * 70)
    print("GROKSTMATE Integration Tests")
    print("=" * 70)
    print()
    
    tests = [
        test_cost_estimation,
        test_project_management,
        test_task_agents,
        test_bot_deployment,
    ]
    
    results = []
    
    for test in tests:
        try:
            result = await test()
            results.append(result)
            print()
        except Exception as e:
            print(f"✗ Test failed: {str(e)}")
            results.append(False)
            print()
    
    print("=" * 70)
    print(f"Tests passed: {sum(results)}/{len(results)}")
    
    if all(results):
        print("All tests PASSED ✓")
        print("=" * 70)
        return 0
    else:
        print("Some tests FAILED ✗")
        print("=" * 70)
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(run_all_tests())
    sys.exit(exit_code)
