# Fixing Common React Integration Issues

## Issue 1: `REACT_APP_BACKEND_URL: undefined`

**Problem:** Your React app can't find the backend URL.

**Solution:**

1. Create `.env` file in your React app root (next to `package.json`):
   ```bash
   REACT_APP_BACKEND_URL=http://localhost:8000
   ```

2. Restart your React app:
   ```bash
   npm start
   ```

3. Verify in your code:
   ```javascript
   console.log('Backend URL:', process.env.REACT_APP_BACKEND_URL);
   // Should log: http://localhost:8000
   ```

## Issue 2: `manifest.json` Syntax Error

**Problem:** `manifest.json:1 Manifest: Line: 1, column: 1, Syntax error.`

**Common Causes:**
- Invalid JSON syntax
- Missing comma
- Trailing comma
- Missing quotes

**Solution:**

Check your `public/manifest.json` file. It should look like this:

```json
{
  "short_name": "GROKSTMATE",
  "name": "GROKSTMATE Construction Management",
  "icons": [
    {
      "src": "favicon.ico",
      "sizes": "64x64 32x32 24x24 16x16",
      "type": "image/x-icon"
    }
  ],
  "start_url": ".",
  "display": "standalone",
  "theme_color": "#000000",
  "background_color": "#ffffff"
}
```

**Common Fixes:**

1. **Remove comments** (JSON doesn't support comments)
2. **Check for trailing commas** (last item shouldn't have comma)
3. **Validate JSON** at [jsonlint.com](https://jsonlint.com)
4. **Regenerate if needed:**
   ```bash
   # Delete and recreate
   rm public/manifest.json
   npx create-react-app temp-app
   cp temp-app/public/manifest.json public/
   rm -rf temp-app
   ```

## Issue 3: Backend Connection Refused

**Problem:** React app can't connect to backend.

**Solution:**

1. **Make sure backend is running:**
   ```bash
   cd GROKSTMATE-
   ./start-backend.sh
   ```

2. **Check backend is accessible:**
   ```bash
   curl http://localhost:8000/health
   # Should return: {"status":"healthy"}
   ```

3. **Verify CORS in browser console:**
   - Open DevTools (F12)
   - Look for CORS errors
   - Should see: "Access-Control-Allow-Origin: http://localhost:3003"

## Issue 4: Port Already in Use

**Problem:** Backend can't start on port 8000.

**Solution:**

1. **Find what's using the port:**
   ```bash
   # Linux/Mac
   lsof -i :8000
   
   # Windows
   netstat -ano | findstr :8000
   ```

2. **Kill the process or use different port:**
   ```bash
   # Use different port
   uvicorn grokstmate.api.main:app --port 8001
   
   # Update React .env
   REACT_APP_BACKEND_URL=http://localhost:8001
   ```

## Complete Setup Checklist

- [ ] Backend installed: `pip install -e .` in GROKSTMATE directory
- [ ] Backend running: `./start-backend.sh` (should see "http://localhost:8000")
- [ ] Backend accessible: `curl http://localhost:8000/health` returns JSON
- [ ] React `.env` created with `REACT_APP_BACKEND_URL=http://localhost:8000`
- [ ] React restarted after creating `.env`
- [ ] `manifest.json` is valid JSON
- [ ] CORS working: Check browser DevTools Network tab

## Testing the Connection

Create `src/test-backend.js` in your React app:

```javascript
// Test backend connection
const testBackend = async () => {
  const API_BASE = process.env.REACT_APP_BACKEND_URL;
  
  console.log('Testing backend at:', API_BASE);
  
  try {
    // 1. Health check
    const health = await fetch(`${API_BASE}/health`);
    console.log('✓ Health check:', await health.json());
    
    // 2. Simple estimate
    const estimate = await fetch(`${API_BASE}/api/v1/estimate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: "Test",
        type: "residential",
        size: 1000
      })
    });
    console.log('✓ Estimate:', await estimate.json());
    
    console.log('✅ Backend connection working!');
  } catch (error) {
    console.error('❌ Backend connection failed:', error);
  }
};

export default testBackend;
```

Use in your `App.js`:
```javascript
import testBackend from './test-backend';
import { useEffect } from 'react';

function App() {
  useEffect(() => {
    testBackend();
  }, []);
  
  // ... rest of your app
}
```

## Still Having Issues?

1. **Check backend logs:**
   - Look for errors in terminal where `start-backend.sh` is running
   - Should see requests coming in

2. **Check React console:**
   - Open browser DevTools (F12)
   - Check Console tab for errors
   - Check Network tab for failed requests

3. **Verify environment:**
   ```bash
   # In GROKSTMATE directory
   python -c "from grokstmate.api.main import app; print('✓ Backend OK')"
   ```

4. **Try curl:**
   ```bash
   curl -X POST http://localhost:8000/api/v1/estimate \
     -H "Content-Type: application/json" \
     -d '{"name":"Test","type":"residential","size":1000}'
   ```

If curl works but React doesn't, it's a CORS or environment issue. Double-check your `.env` file.
